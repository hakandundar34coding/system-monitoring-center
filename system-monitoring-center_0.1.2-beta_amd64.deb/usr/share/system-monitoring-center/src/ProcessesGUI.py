#!/usr/bin/env python3

# ----------------------------------- Processes - Processes GUI Import Function (contains import code of this module in order to avoid running them during module import) -----------------------------------
def processes_gui_import_func():

    global Gtk, os

    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk
    import os


    global Config, MainGUI, Processes, ProcessesMenusGUI
    import Config, MainGUI, Processes, ProcessesMenusGUI


    # Import locale and gettext modules for defining translation texts which will be recognized by gettext application (will be run by programmer externally) and exported into a ".pot" file. 
    global _tr                                                                                # This arbitrary variable will be recognized by gettext application for extracting texts to be translated
    import locale
    from locale import gettext as _tr

    # Define contstants for language translation support
    global application_name
    application_name = "system-monitoring-center"
    translation_files_path = "/usr/share/locale"
    system_current_language = os.environ.get("LANG")

    # Define functions for language translation support
    locale.bindtextdomain(application_name, translation_files_path)
    locale.textdomain(application_name)
    locale.setlocale(locale.LC_ALL, system_current_language)


# ----------------------------------- Processes - Processes GUI Function (the code of this module in order to avoid running them during module import and defines "Processes" tab GUI objects and functions/signals) -----------------------------------
def processes_gui_func():

    # Processes tab GUI objects
    global treeview2101, searchentry2101, button2101, button2102, button2104, button2105
    global radiobutton2101, radiobutton2102, radiobutton2103, radiobutton2104, radiobutton2105, radiobutton2106
    global label2101


    # Processes tab GUI objects - get
    treeview2101 = MainGUI.builder.get_object('treeview2101')
    searchentry2101 = MainGUI.builder.get_object('searchentry2101')
    button2101 = MainGUI.builder.get_object('button2101')
    button2102 = MainGUI.builder.get_object('button2102')
    button2104 = MainGUI.builder.get_object('button2104')
    button2105 = MainGUI.builder.get_object('button2105')
    radiobutton2101 = MainGUI.builder.get_object('radiobutton2101')
    radiobutton2102 = MainGUI.builder.get_object('radiobutton2102')
    radiobutton2103 = MainGUI.builder.get_object('radiobutton2103')
    radiobutton2104 = MainGUI.builder.get_object('radiobutton2104')
    radiobutton2105 = MainGUI.builder.get_object('radiobutton2105')
    radiobutton2106 = MainGUI.builder.get_object('radiobutton2106')
    label2101 = MainGUI.builder.get_object('label2101')


    # Processes tab GUI functions
    def on_treeview2101_button_release_event(widget, event):
        if event.button == 1:                                                                 # Run the following function if mouse is left clicked on the treeview and the mouse button is released.
            Processes.processes_treeview_column_order_width_row_sorting_func()
        if event.button == 3:                                                                 # Open Processes tab right click menu if mouse is right clicked on the treeview (and on any process, otherwise menu will not be shown) and the mouse button is released.
            processes_open_right_click_menu_func(event)

    def on_searchentry2101_changed(widget):
        radiobutton2101.set_active(True)
        radiobutton2104.set_active(True)
        Processes.processes_treeview_filter_search_func()

    def on_button2101_clicked(widget):                                                        # "Processes Tab Customizations" button
        ProcessesMenusGUI.popover2101p.popup()

    def on_button2102_clicked(widget):                                                        # "Define a window by clicking on it and highlight its process" button
        Processes.processes_define_window_func()

    def on_button2104_clicked(widget):                                                        # "Processes Tab Search Customizations" button
        ProcessesMenusGUI.popover2101p2.popup()

    def on_button2105_button_release_event(widget, event):                                    # "Open Process Right Click Menu" button
        if event.button == 1:
            processes_open_right_click_menu_func(event)

    def on_radiobutton2101_toggled(widget):                                                   # "Show all processes" radiobutton
        if radiobutton2101.get_active() == True:
            Processes.processes_treeview_filter_show_all_func()
            radiobutton2104.set_active(True)

    def on_radiobutton2102_toggled(widget):                                                   # "Show processes from this user" radiobutton
        if radiobutton2102.get_active() == True:
            Processes.processes_treeview_filter_show_all_func()
            Processes.processes_treeview_filter_this_user_only_func()
            radiobutton2104.set_active(True)

    def on_radiobutton2103_toggled(widget):                                                   # "Show processes from other users" radiobutton
        if radiobutton2103.get_active() == True:
            Processes.processes_treeview_filter_show_all_func()
            Processes.processes_treeview_filter_other_users_only_func()
            radiobutton2104.set_active(True)

    def on_radiobutton2104_toggled(widget):                                                   # "User defined expand" radiobutton
        if radiobutton2104.get_active() == True:
            pass

    def on_radiobutton2105_toggled(widget):                                                   # "Expand all" radiobutton
        if radiobutton2105.get_active() == True:
            treeview2101.expand_all()

    def on_radiobutton2106_toggled(widget):                                                   # "Collapse all" radiobutton
        if radiobutton2106.get_active() == True:
            treeview2101.collapse_all()


    # Processes tab GUI functions - connect
    treeview2101.connect("button-release-event", on_treeview2101_button_release_event)
    searchentry2101.connect("changed", on_searchentry2101_changed)
    button2101.connect("clicked", on_button2101_clicked)
    button2102.connect("clicked", on_button2102_clicked)
    button2104.connect("clicked", on_button2104_clicked)
    button2105.connect("button-release-event", on_button2105_button_release_event)
    radiobutton2101.connect("toggled", on_radiobutton2101_toggled)
    radiobutton2102.connect("toggled", on_radiobutton2102_toggled)
    radiobutton2103.connect("toggled", on_radiobutton2103_toggled)
    radiobutton2104.connect("toggled", on_radiobutton2104_toggled)
    radiobutton2105.connect("toggled", on_radiobutton2105_toggled)
    radiobutton2106.connect("toggled", on_radiobutton2106_toggled)


    # Processes Tab - Treeview Properties
    treeview2101.set_activate_on_single_click(True)                                           # This command used for activating rows and column header buttons on single click. Column headers have to clicked twice (or clicked() command have to be used twice) for the first sorting operation if this is not used.
    treeview2101.set_fixed_height_mode(True)                                                  # This command is used for lower CPU usage when treeview is updated. It prevents calculating of the row heights on every update. To be able to use this command, "'column'.set_sizing(2)" command have to be used for all columns when adding them into treeview.
    treeview2101.set_headers_clickable(True)
    treeview2101.set_enable_search(True)                                                      # This command is used for searching by pressing on a key on keyboard or by using "Ctrl + F" shortcut.
    treeview2101.set_search_column(2)                                                         # This command used for searching by using entry.
    treeview2101.set_tooltip_column(2)


# ----------------------------------- Processes - Open Right Click Menu Function (gets right clicked process PID and opens right click menu) -----------------------------------
def processes_open_right_click_menu_func(event):

    model, treeiter = treeview2101.get_selection().get_selected()
    if treeiter is None:
        processes_no_process_selected_dialog()
    if treeiter is not None:
        global selected_process_pid
        try:
            selected_process_pid = Processes.pid_list[Processes.processes_data_rows.index(model[treeiter][:])]    # "[:]" is used in order to copy entire list to be able to use it for getting index in the "processes_data_rows" list to use it getting pid of the process.
        except ValueError:                                                                    # It gives error such as "ValueError: [True, 'system-monitoring-center-process-symbolic', 'python3', 2411, 'asush', 'Running', 1.6633495783351964, 98824192, 548507648, 45764608, 0, 16384, 0, 5461, 0, 4, 1727, 1000, 1000, '/usr/bin/python3.9'] is not in list" rarely. It is handled in this situation.
            print("not in list error")
            return
        ProcessesMenusGUI.menu2101m.popup(None, None, None, None, event.button, event.time)
        ProcessesMenusGUI.processes_select_process_nice_option_func()


# ----------------------------------- Processes - No Process Selected Dialog Function (shows a dialog when Open Process Right Click Menu is clicked without selecting a process) -----------------------------------
def processes_no_process_selected_dialog():

    dialog2101 = Gtk.MessageDialog(transient_for=MainGUI.window1, title=_tr("Warning"), flags=0, message_type=Gtk.MessageType.WARNING,
    buttons=Gtk.ButtonsType.CLOSE, text=_tr("Select A Process"), )
    dialog2101.format_secondary_text(_tr("Please select a process and try again for opening the menu"))
    dialog2101.run()
    dialog2101.destroy()
